// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/setting/nls/strings":{group:"Naziv",openAll:"Otvori sve u jednom panelu",dropDown:"Prika\u017ei padaju\u0107i meni",noGroup:"Grupa vid\u017eeta nije postavljena.",groupSetLabel:"Postavi svojstva grupe vid\u017eeta",_localized:{}}});