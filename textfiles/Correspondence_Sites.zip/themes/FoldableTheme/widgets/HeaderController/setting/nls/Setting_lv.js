// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/setting/nls/strings":{group:"Nosaukums",openAll:"Atv\u0113rt visu vien\u0101 panel\u012b",dropDown:"R\u0101d\u012bt nolai\u017eamaj\u0101 izv\u0113ln\u0113",noGroup:"Nav iestat\u012bta logr\u012bku grupa.",groupSetLabel:"Iestat\u012bt logr\u012bku grupas rekviz\u012btus",_localized:{}}});