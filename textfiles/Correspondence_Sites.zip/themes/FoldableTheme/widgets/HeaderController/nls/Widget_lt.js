// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/nls/strings":{_widgetLabel:"Antra\u0161t\u0117s valdiklis",signin:"Prisijungti",signout:"Atsijungti",about:"Apie",signInTo:"Prisijungti \u012f",cantSignOutTip:"\u0160i funkcija veikiant per\u017ei\u016bros re\u017eimu negalima.",more:"daugiau",_localized:{}}});