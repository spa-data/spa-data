// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/nls/strings":{_themeLabel:"\u6298\u53e0\u5f0f\u4e3b\u9898",_layout_default:"\u9ed8\u8ba4\u5e03\u5c40",_layout_layout1:"\u5e03\u5c40 1",_localized:{}}});