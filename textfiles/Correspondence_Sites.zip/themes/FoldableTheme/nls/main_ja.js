// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/nls/strings":{_themeLabel:"\u6298\u308a\u305f\u305f\u307f\u53ef\u80fd\u306a\u30c6\u30fc\u30de",_layout_default:"\u30c7\u30d5\u30a9\u30eb\u30c8\u306e\u30ec\u30a4\u30a2\u30a6\u30c8",_layout_layout1:"\u30ec\u30a4\u30a2\u30a6\u30c8 1",_localized:{}}});